package uac.imsp.clockingapp.View;


public interface IRegisterEmployeeView {
    void onRegisterEmployeeSuccess(String message);
    void onRegisterEmployeeError(String message);
}
