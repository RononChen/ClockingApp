package uac.imsp.clockingapp.Models;

public interface IClocking {

    int getId();
    String getEntryTime();
    String getExitTime();
}
