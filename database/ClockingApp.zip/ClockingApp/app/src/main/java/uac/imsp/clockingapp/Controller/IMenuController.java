package uac.imsp.clockingapp.Controller;

public interface IMenuController {

    void onSearchEmployeeMenu();
    void onUpdateEmployeeMenu();
    void onDeleteEmployeeMenu();
    void onRegisterEmployeeMenu();
    void onClocking();
    void onConsultatisticsMenu();
    void onConsultPresenceReport();
}

