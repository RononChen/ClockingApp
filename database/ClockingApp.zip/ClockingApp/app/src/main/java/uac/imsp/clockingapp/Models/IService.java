package uac.imsp.clockingapp.Models;

public interface IService {
    int getId();
    String getName();
}
