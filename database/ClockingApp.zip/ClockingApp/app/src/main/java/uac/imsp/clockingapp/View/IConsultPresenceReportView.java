package uac.imsp.clockingapp.View;

public interface IConsultPresenceReportView {
    // After employee selecting, the view asks the user to select the month
    void onEmployeeSelected(String message);



}


