package uac.imsp.clockingapp.Models;

public interface IDay {
    int getId();
    String getDate();
}
