package uac.imsp.clockingapp.Models;

public interface IPlanning {
     int getId();
     String getStartTime();
     String getEndTime();
}
