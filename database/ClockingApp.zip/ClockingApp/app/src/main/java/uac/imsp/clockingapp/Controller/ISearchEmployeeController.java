package uac.imsp.clockingapp.Controller;

public interface ISearchEmployeeController {
    //Take the data with which  employee will be searched
    void onSearch(String data);
}
